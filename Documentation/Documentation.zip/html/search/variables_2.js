var searchData=
[
  ['description',['description',['../struct_bee_game_1_1_items_1_1_item.html#a3173b5fb0a51e9063335e5cbf93c2e1b',1,'BeeGame::Items::Item']]]
];
