var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuxyz",
  1: "bcilmpst",
  2: "b",
  3: "bceilmpst",
  4: "abcdefghiklmoprstu",
  5: "bcdfhimnoprstxyz",
  6: "bi",
  7: "abcdfhilmnpqst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator"
};

