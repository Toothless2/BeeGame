var searchData=
[
  ['temperate',['TEMPERATE',['../namespace_bee_game_1_1_enums.html#a9db0f9ac859fab168654d657f248b024ad5938597ebb26919bd3b131a5f076b35',1,'BeeGame.Enums.TEMPERATE()'],['../namespace_bee_game_1_1_enums.html#a66566cbc9da8d1d1e402156b4bd3bf9dad5938597ebb26919bd3b131a5f076b35',1,'BeeGame.Enums.TEMPERATE()']]]
];
