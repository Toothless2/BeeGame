var searchData=
[
  ['temppref',['tempPref',['../struct_bee_game_1_1_bee_1_1_bee_data.html#ab7c3b5184d04319359a7f31fa0a4dc8c',1,'BeeGame::Bee::BeeData']]],
  ['temptol',['tempTol',['../struct_bee_game_1_1_bee_1_1_bee_data.html#aa333655c6249bb86cba999dcdf45c614',1,'BeeGame::Bee::BeeData']]]
];
